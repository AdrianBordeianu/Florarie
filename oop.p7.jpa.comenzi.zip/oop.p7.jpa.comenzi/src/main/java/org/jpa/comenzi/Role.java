package org.jpa.comenzi;

public enum Role {
	ANGAJAT,
	MANAGER,
}
