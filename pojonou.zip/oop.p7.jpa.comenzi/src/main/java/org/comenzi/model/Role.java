package org.comenzi.model;

public enum Role {
	ANGAJAT,
	MANAGER,
}
