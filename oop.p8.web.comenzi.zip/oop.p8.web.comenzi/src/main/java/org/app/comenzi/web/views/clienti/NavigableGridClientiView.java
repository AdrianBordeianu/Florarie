package org.app.comenzi.web.views.clienti;

public class NavigableGridClientiView {

}
