// @ts-nocheck
window.Vaadin = window.Vaadin || {};
window.Vaadin.featureFlags = window.Vaadin.featureFlags || {};
window.Vaadin.featureFlags.exampleFeatureFlag = false;
window.Vaadin.featureFlags.hillaPush = false;
window.Vaadin.featureFlags.hillaEngine = false;
window.Vaadin.featureFlags.oldLicenseChecker = false;
window.Vaadin.featureFlags.collaborationEngineBackend = false;
window.Vaadin.featureFlags.webpackForFrontendBuild = false;
window.Vaadin.featureFlags.enforceFieldValidation = false;
export {};